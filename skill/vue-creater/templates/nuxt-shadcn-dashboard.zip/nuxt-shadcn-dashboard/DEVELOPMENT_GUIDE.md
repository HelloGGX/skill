# Nuxt Shadcn Dashboard - 二次开发指南

![nuxt-shadcn-dashboard-social-card](https://nuxt-shadcn-dashboard.vercel.app/social-card.png)

[![built with nuxt](https://img.shields.io/badge/Built%20With%20Nuxt-18181B?logo=nuxt.js)](https://nuxt.com/)

基于 Nuxt 4、shadcn-vue 和 Tailwind CSS 4 构建的现代化管理后台模板。本指南将帮助您基于此模板进行二次开发，快速构建自己的管理后台应用。

## 在线演示

- 🌐 [在线演示](https://nuxt-shadcn-dashboard.vercel.app)
- 📚 [组件文档](https://shadcn-vue.com/docs/introduction)

## 目录

- [快速开始](#快速开始)
- [项目结构](#项目结构)
- [核心配置](#核心配置)
- [开发指南](#开发指南)
- [组件使用](#组件使用)
- [最佳实践](#最佳实践)
- [常见问题](#常见问题)
- [贡献指南](#贡献指南)

## 快速开始

### 方式一：使用模板创建项目

```bash
# 使用 Nuxt CLI 从模板创建项目
npx nuxi@latest init -t github:dianprata/nuxt-shadcn-dashboard my-dashboard-app

# 进入项目目录
cd my-dashboard-app

# 安装依赖（推荐使用 pnpm）
pnpm install

# 如果没有安装 pnpm，先安装：
npm install -g pnpm
```

### 方式二：克隆仓库

```bash
# 克隆仓库
git clone https://github.com/dianprata/nuxt-shadcn-dashboard.git
cd nuxt-shadcn-dashboard

# 安装依赖
pnpm install
```

### 环境要求

- Node.js 22.x
- pnpm >= 9 (推荐) 或 bun >= 1.0

### 启动开发服务器

```bash
# 开发模式
pnpm dev

# 访问 http://localhost:3000
```

### 构建生产版本

```bash
# 构建
pnpm build

# 预览构建结果
pnpm preview

# 生成静态站点
pnpm generate
```

### 其他命令

```bash
# 类型检查
pnpm typecheck

# 代码检查
pnpm lint

# 代码格式化
pnpm format
```

## 项目结构

```
app/
├── assets/              # 静态资源
│   └── css/            # 全局样式
├── components/          # 组件目录
│   ├── ui/             # shadcn-vue UI 组件
│   ├── layout/         # 布局组件（侧边栏、导航栏等）
│   ├── dashboard/      # 仪表板组件
│   ├── auth/           # 认证相关组件
│   ├── tasks/          # 任务管理组件
│   ├── mail/           # 邮件组件
│   ├── kanban/         # 看板组件
│   └── settings/       # 设置组件
├── composables/         # 组合式函数
├── constants/           # 常量配置
├── layouts/             # 布局模板
├── lib/                 # 工具函数
├── pages/               # 页面路由
├── plugins/             # Nuxt 插件
├── types/               # TypeScript 类型定义
├── app.config.ts        # 应用配置
└── app.vue              # 根组件

public/                  # 公共静态文件
server/                  # 服务端代码
nuxt.config.ts          # Nuxt 配置文件
```

## 核心配置

### 1. 应用设置 (app.config.ts)

应用的全局配置在 `app/app.config.ts` 中定义。这些设置会被保存到浏览器 Cookie 中，用户可以在运行时通过设置面板修改。

```typescript
export default defineAppConfig({
  icon: {
    size: '',    // 默认图标大小
    class: '',   // 默认图标类名
  },
  appSettings: {
    sidebar: {
      collapsible: 'offcanvas', // 侧边栏折叠模式: 'offcanvas' | 'icon' | 'none'
      side: 'left',              // 侧边栏位置: 'left' | 'right'
      variant: 'inset',          // 侧边栏样式: 'sidebar' | 'floating' | 'inset'
    },
    theme: {
      color: 'default',          // 主题颜色: 'default' | 'blue' | 'green' | 'orange' | 'purple' | 'red' | 'teal' | 'yellow' | 'rose'
      type: 'scaled',            // 主题类型: 'default' | 'mono' | 'scaled'
    },
  },
})
```

**可用的配置选项：**

**侧边栏折叠模式 (collapsible):**
- `offcanvas` - 移动端抽屉式，桌面端可折叠
- `icon` - 折叠为图标模式
- `none` - 不可折叠

**侧边栏位置 (side):**
- `left` - 左侧（默认）
- `right` - 右侧

**侧边栏样式 (variant):**
- `sidebar` - 标准侧边栏
- `floating` - 浮动侧边栏
- `inset` - 内嵌侧边栏（默认）

**主题颜色 (color):**
- `default` - 默认主题
- `blue` - 蓝色主题
- `green` - 绿色主题
- `orange` - 橙色主题
- `purple` - 紫色主题
- `red` - 红色主题
- `teal` - 青色主题
- `yellow` - 黄色主题
- `rose` - 玫瑰色主题

**主题类型 (type):**
- `default` - 默认类型
- `mono` - 单色类型
- `scaled` - 缩放类型（默认）

**修改应用设置：**

1. 编辑 `app/app.config.ts` 文件修改默认值
2. 清除浏览器 Cookie 中的 `app_settings`（如果已存在）
3. 刷新页面查看效果

**注意：** 用户在设置面板中的修改会覆盖默认配置，并保存到 Cookie 中。如果要重置为默认设置，需要清除 `app_settings` Cookie。

### 2. Nuxt 配置 (nuxt.config.ts)

主要配置项说明：

```typescript
export default defineNuxtConfig({
  // 开发工具
  devtools: { enabled: true },

  // 全局 CSS
  css: ['~/assets/css/tailwind.css'],

  // Vite 插件配置
  vite: {
    plugins: [tailwindcss()],
  },

  // 模块
  modules: [
    'shadcn-nuxt',           // shadcn-vue 组件
    '@vueuse/nuxt',          // VueUse 工具库
    '@nuxt/eslint',          // ESLint 集成
    '@nuxt/icon',            // 图标支持
    '@pinia/nuxt',           // 状态管理
    '@nuxtjs/color-mode',    // 主题切换
    '@nuxt/fonts',           // 字体优化
  ],

  // shadcn 配置
  shadcn: {
    prefix: '',                      // 组件前缀
    componentDir: '~/components/ui', // 组件目录
  },

  // 颜色模式配置
  colorMode: {
    classSuffix: '',  // 主题类名后缀
  },

  // 图标配置
  icon: {
    provider: 'iconify',
    serverBundle: {
      collections: ['lucide', 'radix-icons', 'mdi', 'bx', 'ion'],
    },
  },

  // 路由规则
  routeRules: {
    '/components': { redirect: '/components/accordion' },
    '/settings': { redirect: '/settings/profile' },
  },

  // 自动导入
  imports: {
    dirs: ['./lib'],
  },
})
```

### 3. 菜单配置 (constants/menus.ts)

侧边栏菜单在 `app/constants/menus.ts` 中配置。菜单采用分组结构，支持多级嵌套：

```typescript
import type { NavMenu, NavMenuItems } from '~/types/nav'

export const navMenu: NavMenu[] = [
  {
    heading: 'General',  // 菜单分组标题
    items: [
      {
        title: 'Home',
        icon: 'i-lucide-home',  // 使用 Iconify 图标格式
        link: '/',
      },
      {
        title: 'Email',
        icon: 'i-lucide-mail',
        link: '/email',
      },
      {
        title: 'Tasks',
        icon: 'i-lucide-calendar-check-2',
        link: '/tasks',
      },
    ],
  },
  {
    heading: 'Apps',
    items: [
      {
        title: 'Kanban Board',
        icon: 'i-lucide-kanban',
        link: '/kanban',
        new: true,  // 显示 "新" 标签
      },
    ],
  },
  {
    heading: 'Pages',
    items: [
      {
        title: 'Settings',
        icon: 'i-lucide-settings',
        children: [  // 支持子菜单
          {
            title: 'Profile',
            icon: 'i-lucide-circle',
            link: '/settings/profile',
          },
          {
            title: 'Account',
            icon: 'i-lucide-circle',
            link: '/settings/account',
          },
        ],
      },
    ],
  },
]

// 底部菜单项
export const navMenuBottom: NavMenuItems = [
  {
    title: 'Help & Support',
    icon: 'i-lucide-circle-help',
    link: 'https://github.com/dianprata/nuxt-shadcn-dashboard',
  },
]
```

**菜单项属性说明：**

- `heading` - 菜单分组标题
- `title` - 菜单项标题
- `icon` - 图标（使用 `i-lucide-*` 格式）
- `link` - 路由链接
- `children` - 子菜单数组
- `new` - 是否显示"新"标签

## 开发指南

### 1. 创建新页面

Nuxt 使用基于文件的路由系统，在 `app/pages/` 目录下创建文件即可自动生成路由。

**示例：创建产品列表页面**

```vue
<!-- app/pages/products/index.vue -->
<script setup lang="ts">
// 定义页面元数据
definePageMeta({
  title: '产品列表',
  layout: 'default',
})

// 获取数据
const { data: products } = await useFetch('/api/products')
</script>

<template>
  <div class="space-y-4">
    <h1 class="text-3xl font-bold">产品列表</h1>
    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card v-for="product in products" :key="product.id">
        <CardHeader>
          <CardTitle>{{ product.name }}</CardTitle>
        </CardHeader>
        <CardContent>
          <p>{{ product.description }}</p>
        </CardContent>
      </Card>
    </div>
  </div>
</template>
```

**路由结构：**

- `pages/index.vue` → `/`
- `pages/products/index.vue` → `/products`
- `pages/products/[id].vue` → `/products/:id`
- `pages/settings/profile.vue` → `/settings/profile`

### 2. 创建自定义组件

**基础组件示例：**

```vue
<!-- app/components/ProductCard.vue -->
<script setup lang="ts">
interface Props {
  name: string
  description: string
  price: number
}

const props = defineProps<Props>()
const emit = defineEmits<{
  click: []
}>()
</script>

<template>
  <Card class="cursor-pointer hover:shadow-lg transition-shadow" @click="emit('click')">
    <CardHeader>
      <CardTitle>{{ name }}</CardTitle>
    </CardHeader>
    <CardContent>
      <p class="text-muted-foreground">{{ description }}</p>
      <p class="text-2xl font-bold mt-4">¥{{ price }}</p>
    </CardContent>
  </Card>
</template>
```

**使用组件：**

```vue
<template>
  <ProductCard
    name="产品名称"
    description="产品描述"
    :price="99.99"
    @click="handleClick"
  />
</template>
```

### 3. 使用 Composables

Composables 是 Vue 3 的组合式函数，用于复用逻辑。

**创建 Composable：**

```typescript
// app/composables/useProducts.ts
export function useProducts() {
  const products = ref([])
  const loading = ref(false)
  const error = ref(null)

  async function fetchProducts() {
    loading.value = true
    try {
      const data = await $fetch('/api/products')
      products.value = data
    } catch (e) {
      error.value = e
    } finally {
      loading.value = false
    }
  }

  return {
    products,
    loading,
    error,
    fetchProducts,
  }
}
```

**使用 Composable：**

```vue
<script setup lang="ts">
const { products, loading, fetchProducts } = useProducts()

onMounted(() => {
  fetchProducts()
})
</script>
```

### 4. 状态管理 (Pinia)

项目已集成 Pinia，用于全局状态管理。

**创建 Store：**

由于项目没有预设的 `stores/` 目录，您需要先创建它：

```bash
mkdir app/stores
```

然后创建 Store 文件：

```typescript
// app/stores/user.ts
import { defineStore } from 'pinia'

export const useUserStore = defineStore('user', () => {
  const user = ref(null)
  const isAuthenticated = computed(() => !!user.value)

  async function login(credentials) {
    const data = await $fetch('/api/auth/login', {
      method: 'POST',
      body: credentials,
    })
    user.value = data.user
  }

  function logout() {
    user.value = null
  }

  return {
    user,
    isAuthenticated,
    login,
    logout,
  }
})
```

**使用 Store：**

```vue
<script setup lang="ts">
const userStore = useUserStore()

async function handleLogin() {
  await userStore.login({ email, password })
  navigateTo('/dashboard')
}
</script>
```

**注意：** Pinia stores 会自动被 Nuxt 识别和导入，无需手动注册。

### 5. API 路由

在 `server/api/` 目录下创建 API 端点。

**示例：创建产品 API**

```typescript
// server/api/products/index.get.ts
export default defineEventHandler(async (event) => {
  // 从数据库获取产品列表
  const products = await db.products.findMany()
  
  return products
})

// server/api/products/[id].get.ts
export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id')
  const product = await db.products.findUnique({ where: { id } })
  
  if (!product) {
    throw createError({
      statusCode: 404,
      message: '产品不存在',
    })
  }
  
  return product
})
```

### 6. 数据获取

Nuxt 提供多种数据获取方式：

**useFetch - 推荐用于组件中**

```vue
<script setup lang="ts">
// 自动处理 SSR 和客户端数据获取
const { data, pending, error, refresh } = await useFetch('/api/products')
</script>
```

**useAsyncData - 更灵活的数据获取**

```vue
<script setup lang="ts">
const { data } = await useAsyncData('products', () => $fetch('/api/products'))
</script>
```

**$fetch - 用于事件处理器**

```vue
<script setup lang="ts">
async function createProduct() {
  const product = await $fetch('/api/products', {
    method: 'POST',
    body: { name, description },
  })
}
</script>
```

## 组件使用

### shadcn-vue 组件

项目使用 shadcn-vue 组件库，所有 UI 组件位于 `app/components/ui/` 目录。

**常用组件示例：**

#### 1. 按钮 (Button)

```vue
<template>
  <Button>默认按钮</Button>
  <Button variant="destructive">删除</Button>
  <Button variant="outline">轮廓按钮</Button>
  <Button variant="ghost">幽灵按钮</Button>
  <Button size="sm">小按钮</Button>
  <Button size="lg">大按钮</Button>
</template>
```

#### 2. 卡片 (Card)

```vue
<template>
  <Card>
    <CardHeader>
      <CardTitle>卡片标题</CardTitle>
      <CardDescription>卡片描述</CardDescription>
    </CardHeader>
    <CardContent>
      <p>卡片内容</p>
    </CardContent>
    <CardFooter>
      <Button>操作</Button>
    </CardFooter>
  </Card>
</template>
```

#### 3. 表单 (Form)

```vue
<script setup lang="ts">
import { z } from 'zod'
import { useForm } from 'vee-validate'
import { toTypedSchema } from '@vee-validate/zod'

const formSchema = toTypedSchema(z.object({
  email: z.string().email('请输入有效的邮箱'),
  password: z.string().min(6, '密码至少6位'),
}))

const { handleSubmit } = useForm({
  validationSchema: formSchema,
})

const onSubmit = handleSubmit((values) => {
  console.log(values)
})
</script>

<template>
  <form @submit="onSubmit">
    <FormField v-slot="{ componentField }" name="email">
      <FormItem>
        <FormLabel>邮箱</FormLabel>
        <FormControl>
          <Input type="email" v-bind="componentField" />
        </FormControl>
        <FormMessage />
      </FormItem>
    </FormField>

    <FormField v-slot="{ componentField }" name="password">
      <FormItem>
        <FormLabel>密码</FormLabel>
        <FormControl>
          <Input type="password" v-bind="componentField" />
        </FormControl>
        <FormMessage />
      </FormItem>
    </FormField>

    <Button type="submit">提交</Button>
  </form>
</template>
```

#### 4. 对话框 (Dialog)

```vue
<script setup lang="ts">
const open = ref(false)
</script>

<template>
  <Dialog v-model:open="open">
    <DialogTrigger as-child>
      <Button>打开对话框</Button>
    </DialogTrigger>
    <DialogContent>
      <DialogHeader>
        <DialogTitle>对话框标题</DialogTitle>
        <DialogDescription>对话框描述</DialogDescription>
      </DialogHeader>
      <div class="py-4">
        <!-- 对话框内容 -->
      </div>
      <DialogFooter>
        <Button @click="open = false">关闭</Button>
      </DialogFooter>
    </DialogContent>
  </Dialog>
</template>
```

#### 5. 表格 (Table)

```vue
<script setup lang="ts">
import { useVueTable, getCoreRowModel } from '@tanstack/vue-table'

const data = ref([
  { id: 1, name: '张三', email: 'zhang@example.com' },
  { id: 2, name: '李四', email: 'li@example.com' },
])

const columns = [
  { accessorKey: 'name', header: '姓名' },
  { accessorKey: 'email', header: '邮箱' },
]

const table = useVueTable({
  data,
  columns,
  getCoreRowModel: getCoreRowModel(),
})
</script>

<template>
  <Table>
    <TableHeader>
      <TableRow v-for="headerGroup in table.getHeaderGroups()" :key="headerGroup.id">
        <TableHead v-for="header in headerGroup.headers" :key="header.id">
          {{ header.column.columnDef.header }}
        </TableHead>
      </TableRow>
    </TableHeader>
    <TableBody>
      <TableRow v-for="row in table.getRowModel().rows" :key="row.id">
        <TableCell v-for="cell in row.getVisibleCells()" :key="cell.id">
          {{ cell.getValue() }}
        </TableCell>
      </TableRow>
    </TableBody>
  </Table>
</template>
```

### 添加新的 shadcn 组件

使用 shadcn-nuxt CLI 添加组件：

```bash
# 添加单个组件
npx shadcn-vue@latest add button

# 添加多个组件
npx shadcn-vue@latest add card dialog table

# 查看所有可用组件
npx shadcn-vue@latest add
```

**组件配置：**

项目的 shadcn 配置在 `app/components.json` 中：

```json
{
  "style": "new-york",
  "typescript": true,
  "tailwind": {
    "css": "app/assets/css/tailwind.css",
    "baseColor": "neutral",
    "cssVariables": true
  },
  "iconLibrary": "lucide",
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components/ui"
  }
}
```

添加的组件会自动放置在 `app/components/ui/` 目录下。

## 最佳实践

### 1. 代码组织

- **组件命名**：使用 PascalCase，如 `ProductCard.vue`
- **文件结构**：按功能模块组织，而非按类型
- **类型定义**：在 `types/` 目录集中管理类型

### 2. 样式规范

项目使用 Tailwind CSS 4.x：

```vue
<template>
  <!-- 推荐：使用 Tailwind 工具类 -->
  <div class="flex items-center gap-4 p-4 rounded-lg bg-card">
    <h2 class="text-2xl font-bold">标题</h2>
  </div>

  <!-- 避免：内联样式 -->
  <div style="display: flex; padding: 16px;">
    <h2 style="font-size: 24px;">标题</h2>
  </div>
</template>
```

**主题变量：**

```css
/* app/assets/css/tailwind.css */
@theme {
  --color-primary: oklch(0.7 0.2 250);
  --color-secondary: oklch(0.6 0.15 200);
}
```

### 3. 性能优化

**懒加载组件：**

```vue
<script setup lang="ts">
// 懒加载大型组件
const HeavyComponent = defineAsyncComponent(() =>
  import('~/components/HeavyComponent.vue')
)
</script>
```

**图片优化：**

```vue
<template>
  <!-- 使用 Nuxt Image -->
  <NuxtImg
    src="/images/product.jpg"
    alt="产品图片"
    width="400"
    height="300"
    loading="lazy"
  />
</template>
```

### 4. 类型安全

充分利用 TypeScript：

```typescript
// 定义接口
interface Product {
  id: string
  name: string
  price: number
  description?: string
}

// 使用泛型
const { data } = await useFetch<Product[]>('/api/products')

// 类型守卫
function isProduct(value: unknown): value is Product {
  return typeof value === 'object' && value !== null && 'id' in value
}
```

### 5. 错误处理

```vue
<script setup lang="ts">
const { data, error } = await useFetch('/api/products')

// 处理错误
if (error.value) {
  showError({
    statusCode: error.value.statusCode,
    message: error.value.message,
  })
}
</script>
```

### 6. SEO 优化

```vue
<script setup lang="ts">
// 设置页面元数据
useHead({
  title: '产品列表',
  meta: [
    { name: 'description', content: '浏览我们的产品列表' },
    { property: 'og:title', content: '产品列表' },
  ],
})

// 或使用 useSeoMeta
useSeoMeta({
  title: '产品列表',
  description: '浏览我们的产品列表',
  ogTitle: '产品列表',
  ogDescription: '浏览我们的产品列表',
})
</script>
```

## 常见问题

### 1. 如何修改主题颜色？

编辑 `app/assets/css/tailwind.css` 文件中的颜色变量：

```css
@theme {
  --color-primary: oklch(0.7 0.2 250);  /* 修改主色调 */
  --color-accent: oklch(0.8 0.15 150);  /* 修改强调色 */
}
```

### 2. 如何添加认证？

参考 `app/pages/(auth)/` 目录下的登录页面示例，结合 Pinia 创建认证 store。

### 3. 如何部署？

```bash
# 构建
pnpm build

# 部署到 Vercel/Netlify
# 1. 连接 Git 仓库
# 2. 设置构建命令: pnpm build
# 3. 设置输出目录: .output/public
```

### 4. 如何连接数据库？

安装数据库客户端（如 Prisma）：

```bash
pnpm add -D prisma
pnpm add @prisma/client
npx prisma init
```

配置数据库连接并在 `server/api/` 中使用。

### 5. 如何自定义侧边栏？

编辑 `app/constants/menus.ts` 添加或修改菜单项，编辑 `app/components/layout/` 下的布局组件自定义样式。

### 6. 图标使用

项目使用 Iconify，支持多个图标集。图标使用 `i-{collection}-{icon}` 格式：

```vue
<template>
  <!-- Lucide 图标 -->
  <Icon name="i-lucide-home" />
  <Icon name="i-lucide-mail" />
  
  <!-- Radix 图标 -->
  <Icon name="i-radix-icons-dashboard" />
  
  <!-- Material Design 图标 -->
  <Icon name="i-mdi-account" />
  
  <!-- Box Icons -->
  <Icon name="i-bx-user" />
  
  <!-- Ionicons -->
  <Icon name="i-ion-settings" />
</template>
```

**可用的图标集：**

项目在 `nuxt.config.ts` 中配置了以下图标集：
- `lucide` - Lucide Icons（推荐使用）
- `radix-icons` - Radix Icons
- `mdi` - Material Design Icons
- `bx` - Box Icons
- `ion` - Ionicons

浏览图标：[https://icon-sets.iconify.design/](https://icon-sets.iconify.design/)

**注意：** 图标名称格式为 `i-{collection}-{icon-name}`，例如 `i-lucide-home`。

## 参考资源

- [Nuxt 官方文档](https://nuxt.com/docs)
- [shadcn-vue 组件文档](https://shadcn-vue.com/docs/introduction)
- [Tailwind CSS 文档](https://tailwindcss.com/docs)
- [VueUse 工具库](https://vueuse.org/)
- [Pinia 状态管理](https://pinia.vuejs.org/)

## 贡献指南

欢迎贡献代码！

1. Fork 本仓库
2. 克隆到本地：`git clone https://github.com/your-username/nuxt-shadcn-dashboard.git`
3. 安装依赖：`pnpm install`
4. 启动开发服务器：`pnpm dev`
5. 创建新分支：`git checkout -b feature/your-feature`
6. 提交更改：`git commit -m "Add your feature"`
7. 推送到分支：`git push origin feature/your-feature`
8. 创建 Pull Request

## 致谢

本项目基于以下优秀的开源项目构建：

- [Nuxt.js](https://nuxtjs.org/) - Vue.js 框架
- [shadcn-vue](https://shadcn-vue.com/) - 可复用的组件集合
- [Tailwind CSS](https://tailwindcss.com/) - CSS 框架

## 许可证

MIT License

Copyright (c) 2024

## 获取帮助

- 查看 [在线演示](https://nuxt-shadcn-dashboard.vercel.app) 了解组件用法
- 阅读 [Nuxt 文档](https://nuxt.com/docs) 学习框架特性
- 参考项目中的现有代码作为模板
- 提交 [Issue](https://github.com/dianprata/nuxt-shadcn-dashboard/issues) 报告问题

祝您开发愉快！🚀
