/// <reference types="shadcn-nuxt" />
/// <reference types="@vueuse/nuxt" />
/// <reference types="@nuxt/eslint" />
/// <reference types="@pinia/nuxt" />
/// <reference types="@nuxt/icon" />
/// <reference types="@nuxtjs/color-mode" />
/// <reference types="@nuxt/fonts" />
/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference path="../node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../node_modules/@nuxt/nitro-server/dist/index.d.mts" />
/// <reference path="../index.d.ts" />
/// <reference path="eslint-typegen.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
