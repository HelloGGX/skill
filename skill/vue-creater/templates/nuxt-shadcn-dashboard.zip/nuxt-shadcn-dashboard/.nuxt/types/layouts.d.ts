import type { ComputedRef, MaybeRef } from 'vue'

type ComponentProps<T> = T extends new(...args: any) => { $props: infer P } ? NonNullable<P>
  : T extends (props: infer P, ...args: any) => any ? P
  : {}

declare module 'nuxt/app' {
  interface NuxtLayouts {
    blank: ComponentProps<typeof import("/Users/xiaoluo/Desktop/work/skill/skill/vue-creater/templates/nuxt-shadcn-dashboard/app/layouts/blank.vue").default>,
    default: ComponentProps<typeof import("/Users/xiaoluo/Desktop/work/skill/skill/vue-creater/templates/nuxt-shadcn-dashboard/app/layouts/default.vue").default>,
}
  export type LayoutKey = keyof NuxtLayouts extends never ? string : keyof NuxtLayouts
  interface PageMeta {
    layout?: MaybeRef<LayoutKey | false> | ComputedRef<LayoutKey | false>
  }
}