![nuxt-shadcn-dashboard-social-card](https://nuxt-shadcn-dashboard.vercel.app/social-card.png)

# Nuxt Shadcn 仪表板

[![built with nuxt][nuxt-src]][nuxt-href]

基于 Nuxt 4、shadcn-vue 和 Tailwind CSS 4 构建的现代化、功能丰富的管理后台模板。

## ✨ 特性

- 🚀 **Nuxt 4** - 最新的 Vue.js 框架，支持 SSR
- 🎨 **shadcn-vue** - 精美、可访问的 UI 组件
- 🎯 **Tailwind CSS 4** - 现代化的实用优先 CSS 框架
- 📱 **响应式设计** - 移动优先的设计理念
- 🌗 **深色模式** - 内置主题切换功能
- 📊 **仪表板组件** - 图表、表格、表单等丰富组件
- 🔐 **认证页面** - 登录、注册和密码重置页面
- ⚡ **快速开发** - 热模块替换和 TypeScript 支持
- 🎭 **图标支持** - Iconify 集成，支持多个图标集
- 📦 **状态管理** - Pinia 响应式状态管理

## 🎯 在线演示

- 🌐 [在线演示](https://nuxt-shadcn-dashboard.vercel.app)
- 📚 [组件文档](https://shadcn-vue.com/docs/introduction)

## 🚀 快速开始

### 创建新项目

```bash
# 使用 Nuxt CLI
npx nuxi@latest init -t github:dianprata/nuxt-shadcn-dashboard my-dashboard-app

# 进入项目目录
cd my-dashboard-app

# 安装依赖
pnpm install

# 启动开发服务器
pnpm dev
```

### 克隆仓库

```bash
git clone https://github.com/dianprata/nuxt-shadcn-dashboard.git
cd nuxt-shadcn-dashboard
pnpm install
pnpm dev
```

## 📖 文档

详细的自定义和开发文档，请查看 [DEVELOPMENT_GUIDE.md](./DEVELOPMENT_GUIDE.md)。

该指南涵盖：
- 📁 项目结构
- ⚙️ 配置选项
- 🛠️ 开发工作流
- 🧩 组件使用
- 🎨 主题和样式
- 📝 最佳实践
- ❓ 常见问题和故障排除

## 🎨 应用设置

在 `app/app.config.ts` 中自定义您的仪表板：

```typescript
export default defineAppConfig({
  appSettings: {
    sidebar: {
      collapsible: 'offcanvas', // 'offcanvas' | 'icon' | 'none'
      side: 'left',              // 'left' | 'right'
      variant: 'inset',          // 'sidebar' | 'floating' | 'inset'
    },
    theme: {
      color: 'default',          // 'default' | 'blue' | 'green' | 'orange' | 'purple' | 'red' | 'teal' | 'yellow' | 'rose'
      type: 'scaled',            // 'default' | 'mono' | 'scaled'
    },
  },
})
```

> **注意：** 更改默认设置后，请清除 `app_settings` cookie。

## 🛠️ 可用脚本

```bash
pnpm dev          # 启动开发服务器
pnpm build        # 构建生产版本
pnpm preview      # 预览生产构建
pnpm generate     # 生成静态站点
pnpm typecheck    # 运行 TypeScript 类型检查
pnpm lint         # 代码检查
pnpm format       # 代码格式化
```

## 📦 技术栈

- **框架：** [Nuxt 4](https://nuxt.com/)
- **UI 组件：** [shadcn-vue](https://shadcn-vue.com/)
- **样式：** [Tailwind CSS 4](https://tailwindcss.com/)
- **图标：** [Iconify](https://iconify.design/)
- **状态管理：** [Pinia](https://pinia.vuejs.org/)
- **表单验证：** [VeeValidate](https://vee-validate.logaretm.com/) + [Zod](https://zod.dev/)
- **图表：** [Unovis](https://unovis.dev/)
- **表格：** [TanStack Table](https://tanstack.com/table)

## 🤝 贡献

欢迎贡献！请遵循以下步骤：

1. Fork 本仓库
2. 创建功能分支：`git checkout -b feature/amazing-feature`
3. 提交更改：`git commit -m 'Add amazing feature'`
4. 推送到分支：`git push origin feature/amazing-feature`
5. 创建 Pull Request

## 📄 许可证

MIT License - 详见 [LICENSE](./LICENSE)

## 🙏 致谢

基于以下优秀项目构建：

- [Nuxt.js](https://nuxtjs.org/)
- [shadcn-vue](https://shadcn-vue.com/)
- [Tailwind CSS](https://tailwindcss.com/)

## 📞 支持

- 📖 [开发文档](./DEVELOPMENT_GUIDE.md)
- 🐛 [报告问题](https://github.com/dianprata/nuxt-shadcn-dashboard/issues)
- 💬 [讨论区](https://github.com/dianprata/nuxt-shadcn-dashboard/discussions)

---

用 ❤️ 制作，作者 [gavin](https://github.com/dianprata)

[nuxt-src]: https://img.shields.io/badge/Built%20With%20Nuxt-18181B?logo=nuxt.js
[nuxt-href]: https://nuxt.com/
